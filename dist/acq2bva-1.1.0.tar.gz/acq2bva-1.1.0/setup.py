# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['acq2bva', 'acq2bva.runners', 'acq2bva.util', 'acq2bva.writers']

package_data = \
{'': ['*']}

install_requires = \
['bioread>=2.1.3,<3.0.0', 'toml>=0.10.2,<0.11.0']

entry_points = \
{'console_scripts': ['acq2bva = acq2bva.runners.command_line:main']}

setup_kwargs = {
    'name': 'acq2bva',
    'version': '1.1.0',
    'description': 'Produces BrainVision Analyzer raw, header and marker files from AcqKnowledge recordings',
    'long_description': '# acq2bva',
    'author': 'Haffi921',
    'author_email': 'haffi921@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Haffi921/acq2bva',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
