# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['acq2bva', 'acq2bva.runners', 'acq2bva.util', 'acq2bva.writers']

package_data = \
{'': ['*']}

install_requires = \
['bioread>=2.1.3,<3.0.0', 'tomli>=1.2.2,<2.0.0']

entry_points = \
{'console_scripts': ['acq2bva = acq2bva.runners.command_line:main']}

setup_kwargs = {
    'name': 'acq2bva',
    'version': '1.3.7',
    'description': 'Produces BrainVision Analyzer raw, header and marker files from AcqKnowledge recordings',
    'long_description': '# acq2bva\n## Description\nWrite the data from an AcqKnowledge file to BrainVision Analyzer format.\n\nProduces a raw data \'.dat\' file, a BrainVision Analyzer header \'.vhdr\' file and, optionally, a BrainVision Analyzer marker \'.vmrk\' file.\n## Usage\n```cmd\nusage:\n    acq2bva acq_file [acq_file ...] output_folder [optional args]\n    acq2bva acq_folder output_folder [optional args]\n\n    If, and only if, the toml file specifies acq_file/folder and output_folder:\n        acq2bva [-s] toml_file [optional args]\n\n    If, and only if, a toml file exists that specifies acq_file/folder and output_folder:\n        acq2bva\n\n    acq2bva [-h, --help]       Show this help message and exit\n    acq2bva -hh                Show the full help message with information on optional args and exit\n    acq2bva [-v, --version]    Show program\'s version number and exit\n\n\nPath variables\n  Either:\n  -acq_file             File or files to convert from AcqKnowledge format to BrainVision Analyzer.\n  -acq_folder           Folder containing files to convert from AcqKnowledge fromat to BrainVision Analyzer.\n  \n  output_folder         Folder where the raw data file, vhdr header file and, optionally, vmkr marker file\n                        will be saved.\n```\n\n## Variables\n```cmd\nChannel Variables:\n  -c INDEX [INDEX ...], --ci INDEX [INDEX ...], --channel-indexes INDEX [INDEX ...]\n    Description: Indexes of channels to include in raw file. Defaults to all channels.\n\n  -n NAME [NAME ...], --names NAME [NAME ...], --channel-names NAME [NAME ...]\n        Description: Names of the channels. Defaults to names given by AcqKnowledge. Useful for renaming channels to something more readable.\n\n  --sc SCALE [SCALE ...], --scales SCALE [SCALE ...], --channel-scales SCALE [SCALE ...]\n        Description: Scales for each channel. Defaults to 1 for every channel.\n\n  -u UNIT [UNIT ...], --units UNIT [UNIT ...], --channel-units UNIT [UNIT ...]\n        Description: Units for each channel. Defaults to units given by AcqKnowledge. Useful for fixing wrong units in recording.\n\nRaw Data Variables:\n  --be LITTLE_ENDIAN, --big-endian LITTLE_ENDIAN\n        Description: Flag to write in big endian format. Defaults to writing in little endian.\n\nMarker Variables:\n  -m, --markers\n        Description: Flag to write a marker file based on a specific marker channel. If true, then marker channel (--mc) must be specified. Optionally, marker map file (--mf) can be specified to provide a description of each marker value. Please refer to the ReadMe or Github page for explanation of a marker map file. Additionally, expected number of markers (--em) can be specified and a warning will be displayed if number of markers found does not correspond to that value.\n\n  --mc INDEX, --marker-channel INDEX\n        Description: A single channel index specifying which channel in the recording to scan for markers.\n\n  --mf FILE, --marker-map-file FILE\n        Description: Path of file specifying a marker mapping from the numerical value the description of that specific marker. For example, 1 -> \'Experiment start\'. Please refer to the ReadMe or Github page for explanation of a marker map file.\n\n  --em NR, --expected-nr-markers NR\n        Description: Expected number of markers from each file. A warning will be displayed if number of markers found does not correspond with this value.\n\nHeader Toml Settings:\n  --hs FILE, --header-settings FILE\n        Description: Toml file to specify settings for the \'.vhdr\' file. Any setting written in here will override settings configured automatically by this program.\n\nAcq2Bva Toml Settings:\n  -s FILE, --settings FILE\n        Description: Toml file to any and all settings specified above. Implicitly loaded if directory contains any of the following files: ["settings.toml", "acq2bva.toml", "acq.toml", "bva.tpml"]. Any setting written in here will be overwritten by settings in the command line. Header settings can be specified here under [header_settings].\n```',
    'author': 'Haffi921',
    'author_email': 'haffi921@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Haffi921/acq2bva',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
